import * as exercises from "./model.mjs";
import express from "express";
import cors from "cors";

const PORT = 3000;

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/**
 * Create a new exercise with the Name, Reps, Weight, Unit and Date provided in the body
 */
app.post("/exercises", (req, res) => {
  exercises
    .createExercise(req.body)
    .then((exercise) => {
      res.status(201).json(exercise);
    })
    .catch(() => {
      res.status(500).json({ error: "Error Adding Exercise" });
    });
});

/**
 * Retrieve exercises.
 * Retrieve by matching ID for edit.
 */
app.get("/exercises", (req, res) => {
  exercises
    .findExercises()
    .then((exercises) => {
      res.json(exercises);
    })
    .catch(() => {
      res.status(500).json({ error: "Error Finding Exercise" });
    });
});

app.get("/exercises/:_id", (req, res) => {
  exercises
    .findExerciseById(req.params._id)
    .then((exercises) => {
      res.json(exercises);
    })
    .catch(() => {
      res
        .status(500)
        .json({ error: `Error Finding Exercise ${req.params._id}` });
    });
});

/**
 * Update the exercise whose id is provided in the path parameter and set
 * its name, reps, weight and unit to the values provided in the body.
 */
app.put("/exercises/:_id", (req, res) => {
  exercises
    .editExercise(req.params._id, req.body)
    .then((modifiedCount) => {
      res.json(modifiedCount);
    })
    .catch(() => {
      res
        .status(500)
        .json({ error: `Error Editing Exercise ${req.params._id}` });
    });
});

/**
 * Delete the exercise whose id is provided in the query parameters
 */
app.delete("/exercises/:_id", (req, res) => {
  exercises
    .removeExercise(req.params)
    .then((deletedCount) => {
      res.json(deletedCount);
    })
    .catch(() => {
      res
        .status(500)
        .json({ error: `Error Deleting Exercise ${req.params._id}` });
    });
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}...`);
});
