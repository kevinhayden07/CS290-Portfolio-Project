import { Link } from "react-router-dom";
import { TiEdit } from "react-icons/ti";
import { TiCancel } from "react-icons/ti";

function Row({ exercises, onDelete }) {
  return (
    <>
      {exercises.map((exercise) => {
        return (
          <tr key={exercise._id}>
            <td>{exercise.name}</td>
            <td>{exercise.reps}</td>
            <td>{exercise.weight}</td>
            <td>{exercise.unit}</td>
            <td>{exercise.date}</td>
            <td>
              <Link to={`/Edit/${exercise._id}`}>
                <TiEdit />
              </Link>
            </td>
            <td>
              <TiCancel onClick={() => onDelete(exercise._id)} />
            </td>
          </tr>
        );
      })}
    </>
  );
}

export default Row;
