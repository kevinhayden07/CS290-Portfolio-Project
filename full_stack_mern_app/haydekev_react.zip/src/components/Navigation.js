import { Link } from "react-router-dom";

function Navigation() {
  return <Link to="/Create">Add an Exercise</Link>;
}

export default Navigation;
