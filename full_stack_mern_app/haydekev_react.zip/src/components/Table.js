import TableHead from "./TableHead";
import Row from "./Row";
import Navigation from "./Navigation";

function Table({ exercises, onDelete }) {
  return (
    <>
      <table>
        <tbody>
          <TableHead />
          <Row exercises={exercises} onDelete={onDelete} />
        </tbody>
      </table>
      <Navigation />
    </>
  );
}

export default Table;
