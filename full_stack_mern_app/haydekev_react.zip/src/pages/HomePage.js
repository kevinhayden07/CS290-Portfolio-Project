import { useState, useEffect } from "react";
import Table from "../components/Table";

function HomePage() {
  const [exercises, setExercises] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/exercises")
      .then((res) => res.json())
      .then((data) => setExercises(data))
      .catch((err) => console.log(err));
  });

  const onDelete = async (_id) => {
    const response = await fetch(`/exercises/${_id}`, { method: "DELETE" });
    if (response.status === 204) {
      const newExercises = exercises.filter((m) => m._id !== _id);
      setExercises(newExercises);
    } else {
      console.error(
        `Failed to delete exercise with _id = ${_id}, status code = ${response.status}`
      );
    }
  };

  return (
    <div className="HomePage">
      <h1>Exercise Tracker</h1>
      <h2>Training Log</h2>
      <Table exercises={exercises} onDelete={onDelete} />
    </div>
  );
}

export default HomePage;
