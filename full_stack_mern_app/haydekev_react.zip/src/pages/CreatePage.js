import { useState } from "react";
import { useNavigate } from "react-router-dom";

const initialFormValues = {
  name: "",
  reps: "",
  weight: "",
  unit: "lbs",
  date: "",
};

function CreatePage() {
  const [formValues, setFormValues] = useState(initialFormValues);
  const navigate = useNavigate();

  const handleChanges = (e) => {
    setFormValues({ ...formValues, [e.target.name]: e.target.value });
  };

  const formatDate = () => {
    if (formValues.date !== "") {
      const dateInput = formValues.date.split("-");
      const newDate = `${dateInput[1]}-${dateInput[2]}-${dateInput[0][2]}${dateInput[0][3]}`;
      formValues.date = newDate;
    }
  };

  const addExercise = (e) => {
    e.preventDefault();
    formatDate();

    fetch("http://localhost:3000/exercises", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formValues),
    })
      .then(() => {
        alert("Creation successful");
        navigate("/");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="CreatePage">
      <h1>Exercise Tracker</h1>
      <h2>Add Exercise</h2>
      <form onSubmit={addExercise}>
        <input
          type="text"
          name="name"
          placeholder="name"
          value={formValues.name}
          onChange={handleChanges}
        />
        <input
          type="number"
          name="reps"
          placeholder="reps"
          value={formValues.reps}
          onChange={handleChanges}
        />
        <input
          type="number"
          name="weight"
          placeholder="weight"
          value={formValues.weight}
          onChange={handleChanges}
        />
        <select name="unit" onChange={handleChanges}>
          <option value="lbs" selected>
            lbs
          </option>
          <option value="kgs">kgs</option>
        </select>
        <input
          type="date"
          name="date"
          placeholder="date"
          value={formValues.date}
          onChange={handleChanges}
        />
        <button>Add</button>
      </form>
    </div>
  );
}

export default CreatePage;
