import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

const initialFormValues = {
  name: "",
  reps: "",
  weight: "",
  unit: "",
  date: "",
};

function EditPage() {
  const [formValues, setFormValues] = useState(initialFormValues);
  const params = useParams();
  const navigate = useNavigate();
  const { _id } = params;

  const handleChanges = (e) => {
    setFormValues({ ...formValues, [e.target.name]: e.target.value });
  };

  const formatDate = () => {
    if (formValues.date !== "") {
      const dateInput = formValues.date.split("-");
      const newDate = `${dateInput[0]}-${dateInput[1]}-${dateInput[2]}`;
      formValues.date = newDate;
    }
  };

  useEffect(() => {
    fetch(`http://localhost:3000/exercises/${_id}`)
      .then((res) => res.json())
      .then((data) => setFormValues(data))
      .catch((err) => console.log(err));
  }, [_id]);

  const editExercise = (e) => {
    e.preventDefault();
    formatDate();

    fetch(`http://localhost:3000/exercises/${_id}`, {
      method: "PUT",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formValues),
    })
      .then(() => {
        alert("Update successful");
        navigate("/");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="EditPage">
      <h1>Exercise Tracker</h1>
      <h2>Edit Exercise</h2>
      <form onSubmit={editExercise}>
        <input
          type="text"
          name="name"
          placeholder="name"
          value={formValues.name}
          onChange={handleChanges}
        />
        <input
          type="number"
          name="reps"
          placeholder="reps"
          value={formValues.reps}
          onChange={handleChanges}
        />
        <input
          type="number"
          name="weight"
          placeholder="weight"
          value={formValues.weight}
          onChange={handleChanges}
        />
        {formValues.unit === "lbs" ? (
          <select name="unit" onChange={handleChanges}>
            <option value="lbs" selected>
              lbs
            </option>
            <option value="kgs">kgs</option>
          </select>
        ) : (
          <select name="unit" onChange={handleChanges}>
            <option value="lbs">lbs</option>
            <option value="kgs" selected>
              kgs
            </option>
          </select>
        )}
        <input
          type="date"
          name="date"
          placeholder="date"
          value={formValues.date}
          onChange={handleChanges}
        />
        <button>Save</button>
      </form>
    </div>
  );
}

export default EditPage;
